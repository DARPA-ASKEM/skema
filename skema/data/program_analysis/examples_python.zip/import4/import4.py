from numpy import *

x = array([1, 2, 3])
y = array([4, 5, 6])
z = concatenate((x, y))
