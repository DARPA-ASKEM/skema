def date(year, day, month):
    return year, month, day


m = 4
date(year=2020, month=m, day=8)
