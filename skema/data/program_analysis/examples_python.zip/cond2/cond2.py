x = 2
y = 4

if x < 5:
    x = x + y
else:
    x = x - 3