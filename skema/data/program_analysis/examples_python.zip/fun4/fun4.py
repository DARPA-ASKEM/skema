def foo(x):
    y = x + 3
    z = y * 2
    return z


x = foo(2)

