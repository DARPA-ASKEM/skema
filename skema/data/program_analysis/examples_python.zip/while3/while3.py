x = 2
y = 3

while x < 5:
    x = x + 1
    x = x + y
