import numpy as np

def main():
    mu = 1
    a = 2
    b = 3
    mu, a, b = np.atleast_1d(mu, a, b)