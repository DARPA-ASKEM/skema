x = 2

while x < 5:
    x = x + 1
