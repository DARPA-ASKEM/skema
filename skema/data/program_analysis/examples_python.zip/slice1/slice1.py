l = list(range(200))
a = 100

l[4:a:5]