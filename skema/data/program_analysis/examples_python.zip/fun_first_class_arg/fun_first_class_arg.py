def foo(x):
    return x + 1
x = [1,2,3]
y = map(foo,x)