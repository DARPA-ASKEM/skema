x = 7

y = x

for i in range(10):
	x = x + i

print(x)  # should be = 52
print(y)  # should be = 7
