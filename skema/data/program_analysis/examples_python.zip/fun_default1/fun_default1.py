def foo(x=1, y=2):
    return x + y

p = foo()
q = foo(y=5)
r = foo(4)
s = foo(3, 4)