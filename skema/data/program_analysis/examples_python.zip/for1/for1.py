def main():
    x = 7
    for i in range(10):
        x = x + i
