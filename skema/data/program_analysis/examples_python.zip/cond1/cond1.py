x = 2

if x < 5:
    x = x + 1
else:
    x = x - 3
