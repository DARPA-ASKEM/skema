def foo(x):
    return x + 2
x = foo(2)
