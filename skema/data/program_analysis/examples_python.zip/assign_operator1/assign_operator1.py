x = 1
y = 2

y += x   # NOTE: PA will translate this into y = y + x
