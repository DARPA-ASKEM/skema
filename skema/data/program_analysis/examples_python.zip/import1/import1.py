import sys
import numpy


x = numpy.array([1,2,3])
sys.exit()
