a = 3

if ((1 < a) or (a < 10)) and (a != 5):
    a = 40