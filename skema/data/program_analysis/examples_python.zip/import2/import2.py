import numpy as np
from sys import exit

x = np.array([1, 2, 3])
exit()
