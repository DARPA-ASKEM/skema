def rec(x):
	rec(x + 1)

z = rec(12)