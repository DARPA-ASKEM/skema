def foo(x):
    return x + 3


x = foo(2)
y = foo(x)
