'''Modules to calculate insolation and orbital variations.

These methods now accept and return ``xarray`` objects
for easier data manipulation and plotting.
'''
