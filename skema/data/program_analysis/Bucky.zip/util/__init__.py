"""Submodule containing various types of utility functions."""
