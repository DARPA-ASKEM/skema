"""Submodule containing the compartment model and all its supporting code."""
