"""Submodule containing objects that manage the input data"""
from .adm_mapping import AdminLevelMapping
from .timeseries import CSSEData, HHSData
