"""Make bucky callable from cmd line."""

if __name__ == "__main__":
    from .cli.main import main as _main

    _main()
