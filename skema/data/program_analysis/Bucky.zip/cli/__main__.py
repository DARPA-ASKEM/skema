"""Make bucky.cli callable from cmd line."""

if __name__ == "__main__":
    from .main import main as _main

    _main()
