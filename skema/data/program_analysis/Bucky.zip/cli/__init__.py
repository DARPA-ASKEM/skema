"""CLI interface for bucky."""
