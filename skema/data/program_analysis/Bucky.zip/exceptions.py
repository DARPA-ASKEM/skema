"""High level bucky related exceptions."""


class BuckyException(Exception):
    """A generic high level base exception."""

    pass  # pylint: disable=unnecessary-pass
