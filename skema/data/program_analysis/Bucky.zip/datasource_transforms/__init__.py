"""Submodule containing scripts to convert raw datasets into more useable formats."""
