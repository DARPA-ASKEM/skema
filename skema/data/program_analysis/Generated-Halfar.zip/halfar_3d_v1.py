import numpy as np
import matplotlib.pyplot as plt


# Constants
A = 1e-7  # Thermal diffusivity
rho_i = 917  # Ice density
g = 9.81  # Acceleration due to gravity
n = 3  # Glen's flow law exponent
h0 = 1000  # Initial ice thickness (meters)
Lx = 1e4  # Characteristic length scale in x-direction (meters)
Ly = 1e4  # Characteristic length scale in y-direction (meters)
Lz = 1000  # Characteristic length scale in z-direction (meters)
t_end = 1000  # Simulation time (years)
dt = 1  # Time step (years)
dx = 100  # Grid spacing in x-direction (meters)
dy = 100  # Grid spacing in y-direction (meters)
dz = 50   # Grid spacing in z-direction (meters)

# Calculate number of grid points in each direction
nx = int(Lx / dx)
ny = int(Ly / dy)
nz = int(Lz / dz)

# Initialize ice thickness field
h = np.ones((nx, ny, nz)) * h0

# Time evolution loop
for t in range(int(t_end / dt)):
    # Calculate gradients in x, y, and z directions
    dh_dx, dh_dy, dh_dz = np.gradient(h, dx, dy, dz)
    
    # Calculate rate of thickness change using Halfar solution
    dh_dt = A * (rho_i * g * h) ** n * (dh_dx**2 + dh_dy**2 + dh_dz**2) ** ((n - 1) / 2)

    # Update ice thickness using explicit finite difference method
    h[1:-1, 1:-1, 1:-1] += dh_dt[1:-1, 1:-1, 1:-1] * dt

# Plot the final ice profile in 3D
x = np.linspace(0, Lx, nx)
y = np.linspace(0, Ly, ny)
z = np.linspace(0, Lz, nz)

X, Y, Z = np.meshgrid(x, y, z, indexing='ij')

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlabel('X (meters)')
ax.set_ylabel('Y (meters)')
ax.set_zlabel('Z (meters)')
ax.set_title('3D Halfar Model Simulation')

# Plot a slice of the ice thickness field
slice_index = int(nz / 2)  # Choose a central slice along the z-direction
ax.plot_surface(X[:,:,slice_index], Y[:,:,slice_index], h[:,:,slice_index], cmap='viridis')

plt.show()
