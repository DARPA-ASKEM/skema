import numpy as np
import matplotlib.pyplot as plt

# Constants
A = 2.1e-24  # Constant for the Halfar solution
n = 3  # Glen's flow law exponent
R = 1e6  # Radius of the dome (meters)
t_end = 1000  # Simulation time (years)
dt = 1  # Time step (years)
dx = 1000  # Grid spacing (meters)

# Calculate number of grid points
nx = int(2 * R / dx)  # Double the radius for symmetric representation

# Initialize ice thickness as a spherical dome shape
x = np.linspace(-R, R, nx)
h = np.sqrt(R**2 - x**2)  # Initial ice thickness (meters), representing a spherical dome

# Time evolution loop
for t in range(int(t_end / dt)):
    # Calculate rate of thickness change using Halfar solution
    dh_dx = np.gradient(h, dx)
    dh_dt = A * (dh_dx ** (n + 2))
    
    # Update ice thickness using explicit finite difference method
    h[1:-1] += dh_dt[1:-1] * dt

# Plot the final ice dome profile
plt.plot(x, h)
plt.xlabel('Distance from Dome Center (meters)')
plt.ylabel('Ice Thickness (meters)')
plt.title('Spherical Halfar Dome Model Simulation')
plt.show()
