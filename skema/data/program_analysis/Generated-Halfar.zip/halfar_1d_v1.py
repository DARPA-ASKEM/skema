import numpy as np
import matplotlib.pyplot as plt

# Constants
A = 1e-7  # Thermal diffusivity
rho_i = 917  # Ice density
g = 9.81  # Acceleration due to gravity
n = 3  # Glen's flow law exponent
h0 = 1000  # Initial ice thickness (meters)
L = 1e6  # Characteristic length scale (meters)
t_end = 1000  # Simulation time (years)
dt = 1  # Time step (years)
dx = 1000  # Grid spacing (meters)

# Calculate number of grid points
nx = int(L / dx)

# Initialize ice thickness
h = np.ones(nx) * h0

# Time evolution loop
for t in range(int(t_end / dt)):
    # Calculate surface slope
    dh_dx = np.gradient(h, dx)

    # Calculate rate of thickness change using Halfar solution
    dh_dt = A * (rho_i * g * h) ** n * dh_dx

    # Update ice thickness using explicit finite difference method
    h[1:-1] += dh_dt[1:-1] * dt

# Plot the final ice profile
x = np.linspace(0, L, nx)
plt.plot(x, h)
plt.xlabel('Distance (meters)')
plt.ylabel('Ice Thickness (meters)')
plt.title('2D Halfar Model Simulation')
plt.show()
