from .utils import calcfunc


class ExecutionInterrupted(Exception):
    pass


__all__ = [calcfunc]
