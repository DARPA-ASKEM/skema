class ImproperlyConfigured(Exception):
    pass
